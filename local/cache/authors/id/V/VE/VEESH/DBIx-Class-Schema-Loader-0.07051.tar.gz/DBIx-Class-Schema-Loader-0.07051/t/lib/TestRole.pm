package TestRole;

use Moose::Role;

sub test_role_method { 'test_role_method works' }

1;
