package TestComponentForMapFQN;
use strict;
use warnings;

sub testcomponentformap_fqn { 'TestComponentForMapFQN works' }

1;
