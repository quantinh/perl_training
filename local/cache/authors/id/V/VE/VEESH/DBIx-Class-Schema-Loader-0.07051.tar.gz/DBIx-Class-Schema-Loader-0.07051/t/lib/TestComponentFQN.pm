package TestComponentFQN;
use strict;
use warnings;

sub testcomponent_fqn { 'TestComponentFQN works' }

1;
