package TestLoaderSubclass_NoRebless;

use strict;
use warnings;
use base qw/DBIx::Class::Schema::Loader::DBI/;

1;
