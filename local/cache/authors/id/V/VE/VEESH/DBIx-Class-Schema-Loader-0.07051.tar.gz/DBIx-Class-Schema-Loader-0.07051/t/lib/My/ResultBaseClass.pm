package My::ResultBaseClass;
use strict;
use warnings;

use base 'DBIx::Class::Core';
1;
