package # hide from PAUSE
    DigestTest::Schema;

use base qw/DBIx::Class::Schema/;

1;
