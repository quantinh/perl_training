#   belongs to t/run/90ensure_class_loaded.tl
package # hide from PAUSE
    DBICTest::SyntaxErrorComponent2;
use warnings;
use strict;

my $str ''; # syntax error

1;
